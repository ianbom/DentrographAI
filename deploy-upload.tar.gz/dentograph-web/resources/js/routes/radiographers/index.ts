import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition, applyUrlDefaults } from './../../wayfinder'
/**
* @see \App\Http\Controllers\RadiographerController::index
 * @see app/Http/Controllers/RadiographerController.php:14
 * @route '/radiographers'
 */
export const index = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index.url(options),
    method: 'get',
})

index.definition = {
    methods: ["get","head"],
    url: '/radiographers',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\RadiographerController::index
 * @see app/Http/Controllers/RadiographerController.php:14
 * @route '/radiographers'
 */
index.url = (options?: RouteQueryOptions) => {
    return index.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\RadiographerController::index
 * @see app/Http/Controllers/RadiographerController.php:14
 * @route '/radiographers'
 */
index.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index.url(options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\RadiographerController::index
 * @see app/Http/Controllers/RadiographerController.php:14
 * @route '/radiographers'
 */
index.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: index.url(options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\RadiographerController::index
 * @see app/Http/Controllers/RadiographerController.php:14
 * @route '/radiographers'
 */
    const indexForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: index.url(options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\RadiographerController::index
 * @see app/Http/Controllers/RadiographerController.php:14
 * @route '/radiographers'
 */
        indexForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: index.url(options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\RadiographerController::index
 * @see app/Http/Controllers/RadiographerController.php:14
 * @route '/radiographers'
 */
        indexForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: index.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    index.form = indexForm
/**
* @see \App\Http\Controllers\RadiographerController::store
 * @see app/Http/Controllers/RadiographerController.php:19
 * @route '/radiographers'
 */
export const store = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: store.url(options),
    method: 'post',
})

store.definition = {
    methods: ["post"],
    url: '/radiographers',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\RadiographerController::store
 * @see app/Http/Controllers/RadiographerController.php:19
 * @route '/radiographers'
 */
store.url = (options?: RouteQueryOptions) => {
    return store.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\RadiographerController::store
 * @see app/Http/Controllers/RadiographerController.php:19
 * @route '/radiographers'
 */
store.post = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: store.url(options),
    method: 'post',
})

    /**
* @see \App\Http\Controllers\RadiographerController::store
 * @see app/Http/Controllers/RadiographerController.php:19
 * @route '/radiographers'
 */
    const storeForm = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: store.url(options),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\RadiographerController::store
 * @see app/Http/Controllers/RadiographerController.php:19
 * @route '/radiographers'
 */
        storeForm.post = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: store.url(options),
            method: 'post',
        })
    
    store.form = storeForm
/**
* @see \App\Http\Controllers\RadiographerController::update
 * @see app/Http/Controllers/RadiographerController.php:28
 * @route '/radiographers/{radiographer}'
 */
export const update = (args: { radiographer: string | number } | [radiographer: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'put'> => ({
    url: update.url(args, options),
    method: 'put',
})

update.definition = {
    methods: ["put","patch"],
    url: '/radiographers/{radiographer}',
} satisfies RouteDefinition<["put","patch"]>

/**
* @see \App\Http\Controllers\RadiographerController::update
 * @see app/Http/Controllers/RadiographerController.php:28
 * @route '/radiographers/{radiographer}'
 */
update.url = (args: { radiographer: string | number } | [radiographer: string | number ] | string | number, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { radiographer: args }
    }

    
    if (Array.isArray(args)) {
        args = {
                    radiographer: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        radiographer: args.radiographer,
                }

    return update.definition.url
            .replace('{radiographer}', parsedArgs.radiographer.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\RadiographerController::update
 * @see app/Http/Controllers/RadiographerController.php:28
 * @route '/radiographers/{radiographer}'
 */
update.put = (args: { radiographer: string | number } | [radiographer: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'put'> => ({
    url: update.url(args, options),
    method: 'put',
})
/**
* @see \App\Http\Controllers\RadiographerController::update
 * @see app/Http/Controllers/RadiographerController.php:28
 * @route '/radiographers/{radiographer}'
 */
update.patch = (args: { radiographer: string | number } | [radiographer: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'patch'> => ({
    url: update.url(args, options),
    method: 'patch',
})

    /**
* @see \App\Http\Controllers\RadiographerController::update
 * @see app/Http/Controllers/RadiographerController.php:28
 * @route '/radiographers/{radiographer}'
 */
    const updateForm = (args: { radiographer: string | number } | [radiographer: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: update.url(args, {
                    [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                        _method: 'PUT',
                        ...(options?.query ?? options?.mergeQuery ?? {}),
                    }
                }),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\RadiographerController::update
 * @see app/Http/Controllers/RadiographerController.php:28
 * @route '/radiographers/{radiographer}'
 */
        updateForm.put = (args: { radiographer: string | number } | [radiographer: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: update.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'PUT',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'post',
        })
            /**
* @see \App\Http\Controllers\RadiographerController::update
 * @see app/Http/Controllers/RadiographerController.php:28
 * @route '/radiographers/{radiographer}'
 */
        updateForm.patch = (args: { radiographer: string | number } | [radiographer: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: update.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'PATCH',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'post',
        })
    
    update.form = updateForm
/**
* @see \App\Http\Controllers\RadiographerController::destroy
 * @see app/Http/Controllers/RadiographerController.php:37
 * @route '/radiographers/{radiographer}'
 */
export const destroy = (args: { radiographer: string | number } | [radiographer: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'delete'> => ({
    url: destroy.url(args, options),
    method: 'delete',
})

destroy.definition = {
    methods: ["delete"],
    url: '/radiographers/{radiographer}',
} satisfies RouteDefinition<["delete"]>

/**
* @see \App\Http\Controllers\RadiographerController::destroy
 * @see app/Http/Controllers/RadiographerController.php:37
 * @route '/radiographers/{radiographer}'
 */
destroy.url = (args: { radiographer: string | number } | [radiographer: string | number ] | string | number, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { radiographer: args }
    }

    
    if (Array.isArray(args)) {
        args = {
                    radiographer: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        radiographer: args.radiographer,
                }

    return destroy.definition.url
            .replace('{radiographer}', parsedArgs.radiographer.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\RadiographerController::destroy
 * @see app/Http/Controllers/RadiographerController.php:37
 * @route '/radiographers/{radiographer}'
 */
destroy.delete = (args: { radiographer: string | number } | [radiographer: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'delete'> => ({
    url: destroy.url(args, options),
    method: 'delete',
})

    /**
* @see \App\Http\Controllers\RadiographerController::destroy
 * @see app/Http/Controllers/RadiographerController.php:37
 * @route '/radiographers/{radiographer}'
 */
    const destroyForm = (args: { radiographer: string | number } | [radiographer: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: destroy.url(args, {
                    [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                        _method: 'DELETE',
                        ...(options?.query ?? options?.mergeQuery ?? {}),
                    }
                }),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\RadiographerController::destroy
 * @see app/Http/Controllers/RadiographerController.php:37
 * @route '/radiographers/{radiographer}'
 */
        destroyForm.delete = (args: { radiographer: string | number } | [radiographer: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: destroy.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'DELETE',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'post',
        })
    
    destroy.form = destroyForm
const radiographers = {
    index: Object.assign(index, index),
store: Object.assign(store, store),
update: Object.assign(update, update),
destroy: Object.assign(destroy, destroy),
}

export default radiographers