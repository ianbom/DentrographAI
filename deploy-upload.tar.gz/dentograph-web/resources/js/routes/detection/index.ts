import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition, applyUrlDefaults } from './../../wayfinder'
/**
* @see \App\Http\Controllers\DetectionController::index
 * @see app/Http/Controllers/DetectionController.php:12
 * @route '/detection'
 */
export const index = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index.url(options),
    method: 'get',
})

index.definition = {
    methods: ["get","head"],
    url: '/detection',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\DetectionController::index
 * @see app/Http/Controllers/DetectionController.php:12
 * @route '/detection'
 */
index.url = (options?: RouteQueryOptions) => {
    return index.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\DetectionController::index
 * @see app/Http/Controllers/DetectionController.php:12
 * @route '/detection'
 */
index.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index.url(options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\DetectionController::index
 * @see app/Http/Controllers/DetectionController.php:12
 * @route '/detection'
 */
index.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: index.url(options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\DetectionController::index
 * @see app/Http/Controllers/DetectionController.php:12
 * @route '/detection'
 */
    const indexForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: index.url(options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\DetectionController::index
 * @see app/Http/Controllers/DetectionController.php:12
 * @route '/detection'
 */
        indexForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: index.url(options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\DetectionController::index
 * @see app/Http/Controllers/DetectionController.php:12
 * @route '/detection'
 */
        indexForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: index.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    index.form = indexForm
/**
* @see \App\Http\Controllers\DetectionController::show
 * @see app/Http/Controllers/DetectionController.php:17
 * @route '/detection/{radiograph}'
 */
export const show = (args: { radiograph: string | number } | [radiograph: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: show.url(args, options),
    method: 'get',
})

show.definition = {
    methods: ["get","head"],
    url: '/detection/{radiograph}',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\DetectionController::show
 * @see app/Http/Controllers/DetectionController.php:17
 * @route '/detection/{radiograph}'
 */
show.url = (args: { radiograph: string | number } | [radiograph: string | number ] | string | number, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { radiograph: args }
    }

    
    if (Array.isArray(args)) {
        args = {
                    radiograph: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        radiograph: args.radiograph,
                }

    return show.definition.url
            .replace('{radiograph}', parsedArgs.radiograph.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\DetectionController::show
 * @see app/Http/Controllers/DetectionController.php:17
 * @route '/detection/{radiograph}'
 */
show.get = (args: { radiograph: string | number } | [radiograph: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: show.url(args, options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\DetectionController::show
 * @see app/Http/Controllers/DetectionController.php:17
 * @route '/detection/{radiograph}'
 */
show.head = (args: { radiograph: string | number } | [radiograph: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: show.url(args, options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\DetectionController::show
 * @see app/Http/Controllers/DetectionController.php:17
 * @route '/detection/{radiograph}'
 */
    const showForm = (args: { radiograph: string | number } | [radiograph: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: show.url(args, options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\DetectionController::show
 * @see app/Http/Controllers/DetectionController.php:17
 * @route '/detection/{radiograph}'
 */
        showForm.get = (args: { radiograph: string | number } | [radiograph: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: show.url(args, options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\DetectionController::show
 * @see app/Http/Controllers/DetectionController.php:17
 * @route '/detection/{radiograph}'
 */
        showForm.head = (args: { radiograph: string | number } | [radiograph: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: show.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    show.form = showForm
const detection = {
    index: Object.assign(index, index),
show: Object.assign(show, show),
}

export default detection