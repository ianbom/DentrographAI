import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition, applyUrlDefaults } from './../../wayfinder'
/**
* @see \App\Http\Controllers\PublicVerificationController::verify
 * @see app/Http/Controllers/PublicVerificationController.php:11
 * @route '/verify/{radiograph}'
 */
export const verify = (args: { radiograph: string | number } | [radiograph: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: verify.url(args, options),
    method: 'get',
})

verify.definition = {
    methods: ["get","head"],
    url: '/verify/{radiograph}',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\PublicVerificationController::verify
 * @see app/Http/Controllers/PublicVerificationController.php:11
 * @route '/verify/{radiograph}'
 */
verify.url = (args: { radiograph: string | number } | [radiograph: string | number ] | string | number, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { radiograph: args }
    }

    
    if (Array.isArray(args)) {
        args = {
                    radiograph: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        radiograph: args.radiograph,
                }

    return verify.definition.url
            .replace('{radiograph}', parsedArgs.radiograph.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\PublicVerificationController::verify
 * @see app/Http/Controllers/PublicVerificationController.php:11
 * @route '/verify/{radiograph}'
 */
verify.get = (args: { radiograph: string | number } | [radiograph: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: verify.url(args, options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\PublicVerificationController::verify
 * @see app/Http/Controllers/PublicVerificationController.php:11
 * @route '/verify/{radiograph}'
 */
verify.head = (args: { radiograph: string | number } | [radiograph: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: verify.url(args, options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\PublicVerificationController::verify
 * @see app/Http/Controllers/PublicVerificationController.php:11
 * @route '/verify/{radiograph}'
 */
    const verifyForm = (args: { radiograph: string | number } | [radiograph: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: verify.url(args, options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\PublicVerificationController::verify
 * @see app/Http/Controllers/PublicVerificationController.php:11
 * @route '/verify/{radiograph}'
 */
        verifyForm.get = (args: { radiograph: string | number } | [radiograph: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: verify.url(args, options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\PublicVerificationController::verify
 * @see app/Http/Controllers/PublicVerificationController.php:11
 * @route '/verify/{radiograph}'
 */
        verifyForm.head = (args: { radiograph: string | number } | [radiograph: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: verify.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    verify.form = verifyForm
const publicMethod = {
    verify: Object.assign(verify, verify),
}

export default publicMethod