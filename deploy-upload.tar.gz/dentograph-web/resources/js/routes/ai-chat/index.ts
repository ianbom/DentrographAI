import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition } from './../../wayfinder'
/**
* @see \App\Http\Controllers\AiChatController::index
 * @see app/Http/Controllers/AiChatController.php:15
 * @route '/ai-chat'
 */
export const index = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index.url(options),
    method: 'get',
})

index.definition = {
    methods: ["get","head"],
    url: '/ai-chat',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\AiChatController::index
 * @see app/Http/Controllers/AiChatController.php:15
 * @route '/ai-chat'
 */
index.url = (options?: RouteQueryOptions) => {
    return index.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\AiChatController::index
 * @see app/Http/Controllers/AiChatController.php:15
 * @route '/ai-chat'
 */
index.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index.url(options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\AiChatController::index
 * @see app/Http/Controllers/AiChatController.php:15
 * @route '/ai-chat'
 */
index.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: index.url(options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\AiChatController::index
 * @see app/Http/Controllers/AiChatController.php:15
 * @route '/ai-chat'
 */
    const indexForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: index.url(options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\AiChatController::index
 * @see app/Http/Controllers/AiChatController.php:15
 * @route '/ai-chat'
 */
        indexForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: index.url(options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\AiChatController::index
 * @see app/Http/Controllers/AiChatController.php:15
 * @route '/ai-chat'
 */
        indexForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: index.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    index.form = indexForm
/**
* @see \App\Http\Controllers\AiChatController::message
 * @see app/Http/Controllers/AiChatController.php:48
 * @route '/ai-chat/message'
 */
export const message = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: message.url(options),
    method: 'post',
})

message.definition = {
    methods: ["post"],
    url: '/ai-chat/message',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\AiChatController::message
 * @see app/Http/Controllers/AiChatController.php:48
 * @route '/ai-chat/message'
 */
message.url = (options?: RouteQueryOptions) => {
    return message.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\AiChatController::message
 * @see app/Http/Controllers/AiChatController.php:48
 * @route '/ai-chat/message'
 */
message.post = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: message.url(options),
    method: 'post',
})

    /**
* @see \App\Http\Controllers\AiChatController::message
 * @see app/Http/Controllers/AiChatController.php:48
 * @route '/ai-chat/message'
 */
    const messageForm = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: message.url(options),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\AiChatController::message
 * @see app/Http/Controllers/AiChatController.php:48
 * @route '/ai-chat/message'
 */
        messageForm.post = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: message.url(options),
            method: 'post',
        })
    
    message.form = messageForm
const aiChat = {
    index: Object.assign(index, index),
message: Object.assign(message, message),
}

export default aiChat