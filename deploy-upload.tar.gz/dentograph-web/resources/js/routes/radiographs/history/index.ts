import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition } from './../../../wayfinder'
/**
* @see \App\Http\Controllers\RadiographController::index
 * @see app/Http/Controllers/RadiographController.php:58
 * @route '/radiographs-history'
 */
export const index = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index.url(options),
    method: 'get',
})

index.definition = {
    methods: ["get","head"],
    url: '/radiographs-history',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\RadiographController::index
 * @see app/Http/Controllers/RadiographController.php:58
 * @route '/radiographs-history'
 */
index.url = (options?: RouteQueryOptions) => {
    return index.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\RadiographController::index
 * @see app/Http/Controllers/RadiographController.php:58
 * @route '/radiographs-history'
 */
index.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index.url(options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\RadiographController::index
 * @see app/Http/Controllers/RadiographController.php:58
 * @route '/radiographs-history'
 */
index.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: index.url(options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\RadiographController::index
 * @see app/Http/Controllers/RadiographController.php:58
 * @route '/radiographs-history'
 */
    const indexForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: index.url(options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\RadiographController::index
 * @see app/Http/Controllers/RadiographController.php:58
 * @route '/radiographs-history'
 */
        indexForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: index.url(options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\RadiographController::index
 * @see app/Http/Controllers/RadiographController.php:58
 * @route '/radiographs-history'
 */
        indexForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: index.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    index.form = indexForm