import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition, applyUrlDefaults } from './../../wayfinder'
/**
* @see \App\Http\Controllers\RadiographController::analyze
 * @see app/Http/Controllers/RadiographController.php:63
 * @route '/radiographs/{radiograph}/analyze'
 */
export const analyze = (args: { radiograph: string | number } | [radiograph: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: analyze.url(args, options),
    method: 'post',
})

analyze.definition = {
    methods: ["post"],
    url: '/radiographs/{radiograph}/analyze',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\RadiographController::analyze
 * @see app/Http/Controllers/RadiographController.php:63
 * @route '/radiographs/{radiograph}/analyze'
 */
analyze.url = (args: { radiograph: string | number } | [radiograph: string | number ] | string | number, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { radiograph: args }
    }

    
    if (Array.isArray(args)) {
        args = {
                    radiograph: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        radiograph: args.radiograph,
                }

    return analyze.definition.url
            .replace('{radiograph}', parsedArgs.radiograph.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\RadiographController::analyze
 * @see app/Http/Controllers/RadiographController.php:63
 * @route '/radiographs/{radiograph}/analyze'
 */
analyze.post = (args: { radiograph: string | number } | [radiograph: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: analyze.url(args, options),
    method: 'post',
})

    /**
* @see \App\Http\Controllers\RadiographController::analyze
 * @see app/Http/Controllers/RadiographController.php:63
 * @route '/radiographs/{radiograph}/analyze'
 */
    const analyzeForm = (args: { radiograph: string | number } | [radiograph: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: analyze.url(args, options),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\RadiographController::analyze
 * @see app/Http/Controllers/RadiographController.php:63
 * @route '/radiographs/{radiograph}/analyze'
 */
        analyzeForm.post = (args: { radiograph: string | number } | [radiograph: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: analyze.url(args, options),
            method: 'post',
        })
    
    analyze.form = analyzeForm
/**
* @see \App\Http\Controllers\RadiographController::finalize
 * @see app/Http/Controllers/RadiographController.php:85
 * @route '/radiographs/{radiograph}/finalize'
 */
export const finalize = (args: { radiograph: string | number } | [radiograph: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: finalize.url(args, options),
    method: 'post',
})

finalize.definition = {
    methods: ["post"],
    url: '/radiographs/{radiograph}/finalize',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\RadiographController::finalize
 * @see app/Http/Controllers/RadiographController.php:85
 * @route '/radiographs/{radiograph}/finalize'
 */
finalize.url = (args: { radiograph: string | number } | [radiograph: string | number ] | string | number, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { radiograph: args }
    }

    
    if (Array.isArray(args)) {
        args = {
                    radiograph: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        radiograph: args.radiograph,
                }

    return finalize.definition.url
            .replace('{radiograph}', parsedArgs.radiograph.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\RadiographController::finalize
 * @see app/Http/Controllers/RadiographController.php:85
 * @route '/radiographs/{radiograph}/finalize'
 */
finalize.post = (args: { radiograph: string | number } | [radiograph: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: finalize.url(args, options),
    method: 'post',
})

    /**
* @see \App\Http\Controllers\RadiographController::finalize
 * @see app/Http/Controllers/RadiographController.php:85
 * @route '/radiographs/{radiograph}/finalize'
 */
    const finalizeForm = (args: { radiograph: string | number } | [radiograph: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: finalize.url(args, options),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\RadiographController::finalize
 * @see app/Http/Controllers/RadiographController.php:85
 * @route '/radiographs/{radiograph}/finalize'
 */
        finalizeForm.post = (args: { radiograph: string | number } | [radiograph: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: finalize.url(args, options),
            method: 'post',
        })
    
    finalize.form = finalizeForm
/**
* @see \App\Http\Controllers\RadiographController::history
 * @see app/Http/Controllers/RadiographController.php:53
 * @route '/radiographs/{radiograph}/history'
 */
export const history = (args: { radiograph: string | number } | [radiograph: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: history.url(args, options),
    method: 'get',
})

history.definition = {
    methods: ["get","head"],
    url: '/radiographs/{radiograph}/history',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\RadiographController::history
 * @see app/Http/Controllers/RadiographController.php:53
 * @route '/radiographs/{radiograph}/history'
 */
history.url = (args: { radiograph: string | number } | [radiograph: string | number ] | string | number, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { radiograph: args }
    }

    
    if (Array.isArray(args)) {
        args = {
                    radiograph: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        radiograph: args.radiograph,
                }

    return history.definition.url
            .replace('{radiograph}', parsedArgs.radiograph.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\RadiographController::history
 * @see app/Http/Controllers/RadiographController.php:53
 * @route '/radiographs/{radiograph}/history'
 */
history.get = (args: { radiograph: string | number } | [radiograph: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: history.url(args, options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\RadiographController::history
 * @see app/Http/Controllers/RadiographController.php:53
 * @route '/radiographs/{radiograph}/history'
 */
history.head = (args: { radiograph: string | number } | [radiograph: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: history.url(args, options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\RadiographController::history
 * @see app/Http/Controllers/RadiographController.php:53
 * @route '/radiographs/{radiograph}/history'
 */
    const historyForm = (args: { radiograph: string | number } | [radiograph: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: history.url(args, options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\RadiographController::history
 * @see app/Http/Controllers/RadiographController.php:53
 * @route '/radiographs/{radiograph}/history'
 */
        historyForm.get = (args: { radiograph: string | number } | [radiograph: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: history.url(args, options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\RadiographController::history
 * @see app/Http/Controllers/RadiographController.php:53
 * @route '/radiographs/{radiograph}/history'
 */
        historyForm.head = (args: { radiograph: string | number } | [radiograph: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: history.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    history.form = historyForm
/**
* @see \App\Http\Controllers\RadiographController::index
 * @see app/Http/Controllers/RadiographController.php:20
 * @route '/radiographs'
 */
export const index = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index.url(options),
    method: 'get',
})

index.definition = {
    methods: ["get","head"],
    url: '/radiographs',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\RadiographController::index
 * @see app/Http/Controllers/RadiographController.php:20
 * @route '/radiographs'
 */
index.url = (options?: RouteQueryOptions) => {
    return index.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\RadiographController::index
 * @see app/Http/Controllers/RadiographController.php:20
 * @route '/radiographs'
 */
index.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index.url(options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\RadiographController::index
 * @see app/Http/Controllers/RadiographController.php:20
 * @route '/radiographs'
 */
index.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: index.url(options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\RadiographController::index
 * @see app/Http/Controllers/RadiographController.php:20
 * @route '/radiographs'
 */
    const indexForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: index.url(options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\RadiographController::index
 * @see app/Http/Controllers/RadiographController.php:20
 * @route '/radiographs'
 */
        indexForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: index.url(options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\RadiographController::index
 * @see app/Http/Controllers/RadiographController.php:20
 * @route '/radiographs'
 */
        indexForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: index.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    index.form = indexForm
/**
* @see \App\Http\Controllers\RadiographController::create
 * @see app/Http/Controllers/RadiographController.php:25
 * @route '/radiographs/create'
 */
export const create = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: create.url(options),
    method: 'get',
})

create.definition = {
    methods: ["get","head"],
    url: '/radiographs/create',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\RadiographController::create
 * @see app/Http/Controllers/RadiographController.php:25
 * @route '/radiographs/create'
 */
create.url = (options?: RouteQueryOptions) => {
    return create.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\RadiographController::create
 * @see app/Http/Controllers/RadiographController.php:25
 * @route '/radiographs/create'
 */
create.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: create.url(options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\RadiographController::create
 * @see app/Http/Controllers/RadiographController.php:25
 * @route '/radiographs/create'
 */
create.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: create.url(options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\RadiographController::create
 * @see app/Http/Controllers/RadiographController.php:25
 * @route '/radiographs/create'
 */
    const createForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: create.url(options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\RadiographController::create
 * @see app/Http/Controllers/RadiographController.php:25
 * @route '/radiographs/create'
 */
        createForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: create.url(options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\RadiographController::create
 * @see app/Http/Controllers/RadiographController.php:25
 * @route '/radiographs/create'
 */
        createForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: create.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    create.form = createForm
/**
* @see \App\Http\Controllers\RadiographController::store
 * @see app/Http/Controllers/RadiographController.php:30
 * @route '/radiographs'
 */
export const store = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: store.url(options),
    method: 'post',
})

store.definition = {
    methods: ["post"],
    url: '/radiographs',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\RadiographController::store
 * @see app/Http/Controllers/RadiographController.php:30
 * @route '/radiographs'
 */
store.url = (options?: RouteQueryOptions) => {
    return store.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\RadiographController::store
 * @see app/Http/Controllers/RadiographController.php:30
 * @route '/radiographs'
 */
store.post = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: store.url(options),
    method: 'post',
})

    /**
* @see \App\Http\Controllers\RadiographController::store
 * @see app/Http/Controllers/RadiographController.php:30
 * @route '/radiographs'
 */
    const storeForm = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: store.url(options),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\RadiographController::store
 * @see app/Http/Controllers/RadiographController.php:30
 * @route '/radiographs'
 */
        storeForm.post = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: store.url(options),
            method: 'post',
        })
    
    store.form = storeForm
/**
* @see \App\Http\Controllers\RadiographController::show
 * @see app/Http/Controllers/RadiographController.php:39
 * @route '/radiographs/{radiograph}'
 */
export const show = (args: { radiograph: string | number } | [radiograph: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: show.url(args, options),
    method: 'get',
})

show.definition = {
    methods: ["get","head"],
    url: '/radiographs/{radiograph}',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\RadiographController::show
 * @see app/Http/Controllers/RadiographController.php:39
 * @route '/radiographs/{radiograph}'
 */
show.url = (args: { radiograph: string | number } | [radiograph: string | number ] | string | number, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { radiograph: args }
    }

    
    if (Array.isArray(args)) {
        args = {
                    radiograph: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        radiograph: args.radiograph,
                }

    return show.definition.url
            .replace('{radiograph}', parsedArgs.radiograph.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\RadiographController::show
 * @see app/Http/Controllers/RadiographController.php:39
 * @route '/radiographs/{radiograph}'
 */
show.get = (args: { radiograph: string | number } | [radiograph: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: show.url(args, options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\RadiographController::show
 * @see app/Http/Controllers/RadiographController.php:39
 * @route '/radiographs/{radiograph}'
 */
show.head = (args: { radiograph: string | number } | [radiograph: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: show.url(args, options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\RadiographController::show
 * @see app/Http/Controllers/RadiographController.php:39
 * @route '/radiographs/{radiograph}'
 */
    const showForm = (args: { radiograph: string | number } | [radiograph: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: show.url(args, options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\RadiographController::show
 * @see app/Http/Controllers/RadiographController.php:39
 * @route '/radiographs/{radiograph}'
 */
        showForm.get = (args: { radiograph: string | number } | [radiograph: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: show.url(args, options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\RadiographController::show
 * @see app/Http/Controllers/RadiographController.php:39
 * @route '/radiographs/{radiograph}'
 */
        showForm.head = (args: { radiograph: string | number } | [radiograph: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: show.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    show.form = showForm
/**
* @see \App\Http\Controllers\RadiographController::destroy
 * @see app/Http/Controllers/RadiographController.php:94
 * @route '/radiographs/{radiograph}'
 */
export const destroy = (args: { radiograph: string | number } | [radiograph: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'delete'> => ({
    url: destroy.url(args, options),
    method: 'delete',
})

destroy.definition = {
    methods: ["delete"],
    url: '/radiographs/{radiograph}',
} satisfies RouteDefinition<["delete"]>

/**
* @see \App\Http\Controllers\RadiographController::destroy
 * @see app/Http/Controllers/RadiographController.php:94
 * @route '/radiographs/{radiograph}'
 */
destroy.url = (args: { radiograph: string | number } | [radiograph: string | number ] | string | number, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { radiograph: args }
    }

    
    if (Array.isArray(args)) {
        args = {
                    radiograph: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        radiograph: args.radiograph,
                }

    return destroy.definition.url
            .replace('{radiograph}', parsedArgs.radiograph.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\RadiographController::destroy
 * @see app/Http/Controllers/RadiographController.php:94
 * @route '/radiographs/{radiograph}'
 */
destroy.delete = (args: { radiograph: string | number } | [radiograph: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'delete'> => ({
    url: destroy.url(args, options),
    method: 'delete',
})

    /**
* @see \App\Http\Controllers\RadiographController::destroy
 * @see app/Http/Controllers/RadiographController.php:94
 * @route '/radiographs/{radiograph}'
 */
    const destroyForm = (args: { radiograph: string | number } | [radiograph: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: destroy.url(args, {
                    [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                        _method: 'DELETE',
                        ...(options?.query ?? options?.mergeQuery ?? {}),
                    }
                }),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\RadiographController::destroy
 * @see app/Http/Controllers/RadiographController.php:94
 * @route '/radiographs/{radiograph}'
 */
        destroyForm.delete = (args: { radiograph: string | number } | [radiograph: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: destroy.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'DELETE',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'post',
        })
    
    destroy.form = destroyForm
const radiographs = {
    analyze: Object.assign(analyze, analyze),
finalize: Object.assign(finalize, finalize),
history: Object.assign(history, history),
index: Object.assign(index, index),
create: Object.assign(create, create),
store: Object.assign(store, store),
show: Object.assign(show, show),
destroy: Object.assign(destroy, destroy),
}

export default radiographs