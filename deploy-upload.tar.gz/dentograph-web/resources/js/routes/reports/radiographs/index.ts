import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition, applyUrlDefaults } from './../../../wayfinder'
/**
* @see \App\Http\Controllers\ReportController::pdf
 * @see app/Http/Controllers/ReportController.php:14
 * @route '/reports/radiographs/{radiograph}/pdf'
 */
export const pdf = (args: { radiograph: string | number } | [radiograph: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: pdf.url(args, options),
    method: 'get',
})

pdf.definition = {
    methods: ["get","head"],
    url: '/reports/radiographs/{radiograph}/pdf',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\ReportController::pdf
 * @see app/Http/Controllers/ReportController.php:14
 * @route '/reports/radiographs/{radiograph}/pdf'
 */
pdf.url = (args: { radiograph: string | number } | [radiograph: string | number ] | string | number, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { radiograph: args }
    }

    
    if (Array.isArray(args)) {
        args = {
                    radiograph: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        radiograph: args.radiograph,
                }

    return pdf.definition.url
            .replace('{radiograph}', parsedArgs.radiograph.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\ReportController::pdf
 * @see app/Http/Controllers/ReportController.php:14
 * @route '/reports/radiographs/{radiograph}/pdf'
 */
pdf.get = (args: { radiograph: string | number } | [radiograph: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: pdf.url(args, options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\ReportController::pdf
 * @see app/Http/Controllers/ReportController.php:14
 * @route '/reports/radiographs/{radiograph}/pdf'
 */
pdf.head = (args: { radiograph: string | number } | [radiograph: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: pdf.url(args, options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\ReportController::pdf
 * @see app/Http/Controllers/ReportController.php:14
 * @route '/reports/radiographs/{radiograph}/pdf'
 */
    const pdfForm = (args: { radiograph: string | number } | [radiograph: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: pdf.url(args, options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\ReportController::pdf
 * @see app/Http/Controllers/ReportController.php:14
 * @route '/reports/radiographs/{radiograph}/pdf'
 */
        pdfForm.get = (args: { radiograph: string | number } | [radiograph: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: pdf.url(args, options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\ReportController::pdf
 * @see app/Http/Controllers/ReportController.php:14
 * @route '/reports/radiographs/{radiograph}/pdf'
 */
        pdfForm.head = (args: { radiograph: string | number } | [radiograph: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: pdf.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    pdf.form = pdfForm
/**
* @see \App\Http\Controllers\ReportController::download
 * @see app/Http/Controllers/ReportController.php:27
 * @route '/reports/radiographs/{radiograph}/download'
 */
export const download = (args: { radiograph: string | number } | [radiograph: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: download.url(args, options),
    method: 'get',
})

download.definition = {
    methods: ["get","head"],
    url: '/reports/radiographs/{radiograph}/download',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\ReportController::download
 * @see app/Http/Controllers/ReportController.php:27
 * @route '/reports/radiographs/{radiograph}/download'
 */
download.url = (args: { radiograph: string | number } | [radiograph: string | number ] | string | number, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { radiograph: args }
    }

    
    if (Array.isArray(args)) {
        args = {
                    radiograph: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        radiograph: args.radiograph,
                }

    return download.definition.url
            .replace('{radiograph}', parsedArgs.radiograph.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\ReportController::download
 * @see app/Http/Controllers/ReportController.php:27
 * @route '/reports/radiographs/{radiograph}/download'
 */
download.get = (args: { radiograph: string | number } | [radiograph: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: download.url(args, options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\ReportController::download
 * @see app/Http/Controllers/ReportController.php:27
 * @route '/reports/radiographs/{radiograph}/download'
 */
download.head = (args: { radiograph: string | number } | [radiograph: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: download.url(args, options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\ReportController::download
 * @see app/Http/Controllers/ReportController.php:27
 * @route '/reports/radiographs/{radiograph}/download'
 */
    const downloadForm = (args: { radiograph: string | number } | [radiograph: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: download.url(args, options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\ReportController::download
 * @see app/Http/Controllers/ReportController.php:27
 * @route '/reports/radiographs/{radiograph}/download'
 */
        downloadForm.get = (args: { radiograph: string | number } | [radiograph: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: download.url(args, options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\ReportController::download
 * @see app/Http/Controllers/ReportController.php:27
 * @route '/reports/radiographs/{radiograph}/download'
 */
        downloadForm.head = (args: { radiograph: string | number } | [radiograph: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: download.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    download.form = downloadForm
const radiographs = {
    pdf: Object.assign(pdf, pdf),
download: Object.assign(download, download),
}

export default radiographs