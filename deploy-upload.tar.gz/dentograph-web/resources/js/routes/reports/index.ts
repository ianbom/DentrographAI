import radiographs from './radiographs'
const reports = {
    radiographs: Object.assign(radiographs, radiographs),
}

export default reports