import PublicVerificationController from './PublicVerificationController'
import DashboardController from './DashboardController'
import AiChatController from './AiChatController'
import UserController from './UserController'
import KnowledgeController from './KnowledgeController'
import DoctorController from './DoctorController'
import RadiographerController from './RadiographerController'
import DetectionController from './DetectionController'
import PatientController from './PatientController'
import RadiographController from './RadiographController'
import VerificationController from './VerificationController'
import ReportController from './ReportController'
import Settings from './Settings'
const Controllers = {
    PublicVerificationController: Object.assign(PublicVerificationController, PublicVerificationController),
DashboardController: Object.assign(DashboardController, DashboardController),
AiChatController: Object.assign(AiChatController, AiChatController),
UserController: Object.assign(UserController, UserController),
KnowledgeController: Object.assign(KnowledgeController, KnowledgeController),
DoctorController: Object.assign(DoctorController, DoctorController),
RadiographerController: Object.assign(RadiographerController, RadiographerController),
DetectionController: Object.assign(DetectionController, DetectionController),
PatientController: Object.assign(PatientController, PatientController),
RadiographController: Object.assign(RadiographController, RadiographController),
VerificationController: Object.assign(VerificationController, VerificationController),
ReportController: Object.assign(ReportController, ReportController),
Settings: Object.assign(Settings, Settings),
}

export default Controllers