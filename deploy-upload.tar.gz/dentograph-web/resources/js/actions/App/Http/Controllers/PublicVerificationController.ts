import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition, applyUrlDefaults } from './../../../../wayfinder'
/**
* @see \App\Http\Controllers\PublicVerificationController::show
 * @see app/Http/Controllers/PublicVerificationController.php:11
 * @route '/verify/{radiograph}'
 */
export const show = (args: { radiograph: string | number } | [radiograph: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: show.url(args, options),
    method: 'get',
})

show.definition = {
    methods: ["get","head"],
    url: '/verify/{radiograph}',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\PublicVerificationController::show
 * @see app/Http/Controllers/PublicVerificationController.php:11
 * @route '/verify/{radiograph}'
 */
show.url = (args: { radiograph: string | number } | [radiograph: string | number ] | string | number, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { radiograph: args }
    }

    
    if (Array.isArray(args)) {
        args = {
                    radiograph: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        radiograph: args.radiograph,
                }

    return show.definition.url
            .replace('{radiograph}', parsedArgs.radiograph.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\PublicVerificationController::show
 * @see app/Http/Controllers/PublicVerificationController.php:11
 * @route '/verify/{radiograph}'
 */
show.get = (args: { radiograph: string | number } | [radiograph: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: show.url(args, options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\PublicVerificationController::show
 * @see app/Http/Controllers/PublicVerificationController.php:11
 * @route '/verify/{radiograph}'
 */
show.head = (args: { radiograph: string | number } | [radiograph: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: show.url(args, options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\PublicVerificationController::show
 * @see app/Http/Controllers/PublicVerificationController.php:11
 * @route '/verify/{radiograph}'
 */
    const showForm = (args: { radiograph: string | number } | [radiograph: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: show.url(args, options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\PublicVerificationController::show
 * @see app/Http/Controllers/PublicVerificationController.php:11
 * @route '/verify/{radiograph}'
 */
        showForm.get = (args: { radiograph: string | number } | [radiograph: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: show.url(args, options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\PublicVerificationController::show
 * @see app/Http/Controllers/PublicVerificationController.php:11
 * @route '/verify/{radiograph}'
 */
        showForm.head = (args: { radiograph: string | number } | [radiograph: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: show.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    show.form = showForm
const PublicVerificationController = { show }

export default PublicVerificationController