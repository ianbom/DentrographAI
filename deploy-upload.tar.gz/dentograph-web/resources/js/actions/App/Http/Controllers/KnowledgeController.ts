import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition, applyUrlDefaults } from './../../../../wayfinder'
/**
* @see \App\Http\Controllers\KnowledgeController::index
 * @see app/Http/Controllers/KnowledgeController.php:18
 * @route '/knowledge'
 */
export const index = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index.url(options),
    method: 'get',
})

index.definition = {
    methods: ["get","head"],
    url: '/knowledge',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\KnowledgeController::index
 * @see app/Http/Controllers/KnowledgeController.php:18
 * @route '/knowledge'
 */
index.url = (options?: RouteQueryOptions) => {
    return index.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\KnowledgeController::index
 * @see app/Http/Controllers/KnowledgeController.php:18
 * @route '/knowledge'
 */
index.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index.url(options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\KnowledgeController::index
 * @see app/Http/Controllers/KnowledgeController.php:18
 * @route '/knowledge'
 */
index.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: index.url(options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\KnowledgeController::index
 * @see app/Http/Controllers/KnowledgeController.php:18
 * @route '/knowledge'
 */
    const indexForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: index.url(options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\KnowledgeController::index
 * @see app/Http/Controllers/KnowledgeController.php:18
 * @route '/knowledge'
 */
        indexForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: index.url(options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\KnowledgeController::index
 * @see app/Http/Controllers/KnowledgeController.php:18
 * @route '/knowledge'
 */
        indexForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: index.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    index.form = indexForm
/**
* @see \App\Http\Controllers\KnowledgeController::create
 * @see app/Http/Controllers/KnowledgeController.php:39
 * @route '/knowledge/create'
 */
export const create = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: create.url(options),
    method: 'get',
})

create.definition = {
    methods: ["get","head"],
    url: '/knowledge/create',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\KnowledgeController::create
 * @see app/Http/Controllers/KnowledgeController.php:39
 * @route '/knowledge/create'
 */
create.url = (options?: RouteQueryOptions) => {
    return create.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\KnowledgeController::create
 * @see app/Http/Controllers/KnowledgeController.php:39
 * @route '/knowledge/create'
 */
create.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: create.url(options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\KnowledgeController::create
 * @see app/Http/Controllers/KnowledgeController.php:39
 * @route '/knowledge/create'
 */
create.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: create.url(options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\KnowledgeController::create
 * @see app/Http/Controllers/KnowledgeController.php:39
 * @route '/knowledge/create'
 */
    const createForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: create.url(options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\KnowledgeController::create
 * @see app/Http/Controllers/KnowledgeController.php:39
 * @route '/knowledge/create'
 */
        createForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: create.url(options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\KnowledgeController::create
 * @see app/Http/Controllers/KnowledgeController.php:39
 * @route '/knowledge/create'
 */
        createForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: create.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    create.form = createForm
/**
* @see \App\Http\Controllers\KnowledgeController::store
 * @see app/Http/Controllers/KnowledgeController.php:49
 * @route '/knowledge'
 */
export const store = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: store.url(options),
    method: 'post',
})

store.definition = {
    methods: ["post"],
    url: '/knowledge',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\KnowledgeController::store
 * @see app/Http/Controllers/KnowledgeController.php:49
 * @route '/knowledge'
 */
store.url = (options?: RouteQueryOptions) => {
    return store.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\KnowledgeController::store
 * @see app/Http/Controllers/KnowledgeController.php:49
 * @route '/knowledge'
 */
store.post = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: store.url(options),
    method: 'post',
})

    /**
* @see \App\Http\Controllers\KnowledgeController::store
 * @see app/Http/Controllers/KnowledgeController.php:49
 * @route '/knowledge'
 */
    const storeForm = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: store.url(options),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\KnowledgeController::store
 * @see app/Http/Controllers/KnowledgeController.php:49
 * @route '/knowledge'
 */
        storeForm.post = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: store.url(options),
            method: 'post',
        })
    
    store.form = storeForm
/**
* @see \App\Http\Controllers\KnowledgeController::edit
 * @see app/Http/Controllers/KnowledgeController.php:58
 * @route '/knowledge/{knowledge}/edit'
 */
export const edit = (args: { knowledge: string | number | { id: string | number } } | [knowledge: string | number | { id: string | number } ] | string | number | { id: string | number }, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: edit.url(args, options),
    method: 'get',
})

edit.definition = {
    methods: ["get","head"],
    url: '/knowledge/{knowledge}/edit',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\KnowledgeController::edit
 * @see app/Http/Controllers/KnowledgeController.php:58
 * @route '/knowledge/{knowledge}/edit'
 */
edit.url = (args: { knowledge: string | number | { id: string | number } } | [knowledge: string | number | { id: string | number } ] | string | number | { id: string | number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { knowledge: args }
    }

            if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
            args = { knowledge: args.id }
        }
    
    if (Array.isArray(args)) {
        args = {
                    knowledge: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        knowledge: typeof args.knowledge === 'object'
                ? args.knowledge.id
                : args.knowledge,
                }

    return edit.definition.url
            .replace('{knowledge}', parsedArgs.knowledge.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\KnowledgeController::edit
 * @see app/Http/Controllers/KnowledgeController.php:58
 * @route '/knowledge/{knowledge}/edit'
 */
edit.get = (args: { knowledge: string | number | { id: string | number } } | [knowledge: string | number | { id: string | number } ] | string | number | { id: string | number }, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: edit.url(args, options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\KnowledgeController::edit
 * @see app/Http/Controllers/KnowledgeController.php:58
 * @route '/knowledge/{knowledge}/edit'
 */
edit.head = (args: { knowledge: string | number | { id: string | number } } | [knowledge: string | number | { id: string | number } ] | string | number | { id: string | number }, options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: edit.url(args, options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\KnowledgeController::edit
 * @see app/Http/Controllers/KnowledgeController.php:58
 * @route '/knowledge/{knowledge}/edit'
 */
    const editForm = (args: { knowledge: string | number | { id: string | number } } | [knowledge: string | number | { id: string | number } ] | string | number | { id: string | number }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: edit.url(args, options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\KnowledgeController::edit
 * @see app/Http/Controllers/KnowledgeController.php:58
 * @route '/knowledge/{knowledge}/edit'
 */
        editForm.get = (args: { knowledge: string | number | { id: string | number } } | [knowledge: string | number | { id: string | number } ] | string | number | { id: string | number }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: edit.url(args, options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\KnowledgeController::edit
 * @see app/Http/Controllers/KnowledgeController.php:58
 * @route '/knowledge/{knowledge}/edit'
 */
        editForm.head = (args: { knowledge: string | number | { id: string | number } } | [knowledge: string | number | { id: string | number } ] | string | number | { id: string | number }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: edit.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    edit.form = editForm
/**
* @see \App\Http\Controllers\KnowledgeController::update
 * @see app/Http/Controllers/KnowledgeController.php:77
 * @route '/knowledge/{knowledge}'
 */
export const update = (args: { knowledge: string | number | { id: string | number } } | [knowledge: string | number | { id: string | number } ] | string | number | { id: string | number }, options?: RouteQueryOptions): RouteDefinition<'put'> => ({
    url: update.url(args, options),
    method: 'put',
})

update.definition = {
    methods: ["put","patch"],
    url: '/knowledge/{knowledge}',
} satisfies RouteDefinition<["put","patch"]>

/**
* @see \App\Http\Controllers\KnowledgeController::update
 * @see app/Http/Controllers/KnowledgeController.php:77
 * @route '/knowledge/{knowledge}'
 */
update.url = (args: { knowledge: string | number | { id: string | number } } | [knowledge: string | number | { id: string | number } ] | string | number | { id: string | number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { knowledge: args }
    }

            if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
            args = { knowledge: args.id }
        }
    
    if (Array.isArray(args)) {
        args = {
                    knowledge: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        knowledge: typeof args.knowledge === 'object'
                ? args.knowledge.id
                : args.knowledge,
                }

    return update.definition.url
            .replace('{knowledge}', parsedArgs.knowledge.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\KnowledgeController::update
 * @see app/Http/Controllers/KnowledgeController.php:77
 * @route '/knowledge/{knowledge}'
 */
update.put = (args: { knowledge: string | number | { id: string | number } } | [knowledge: string | number | { id: string | number } ] | string | number | { id: string | number }, options?: RouteQueryOptions): RouteDefinition<'put'> => ({
    url: update.url(args, options),
    method: 'put',
})
/**
* @see \App\Http\Controllers\KnowledgeController::update
 * @see app/Http/Controllers/KnowledgeController.php:77
 * @route '/knowledge/{knowledge}'
 */
update.patch = (args: { knowledge: string | number | { id: string | number } } | [knowledge: string | number | { id: string | number } ] | string | number | { id: string | number }, options?: RouteQueryOptions): RouteDefinition<'patch'> => ({
    url: update.url(args, options),
    method: 'patch',
})

    /**
* @see \App\Http\Controllers\KnowledgeController::update
 * @see app/Http/Controllers/KnowledgeController.php:77
 * @route '/knowledge/{knowledge}'
 */
    const updateForm = (args: { knowledge: string | number | { id: string | number } } | [knowledge: string | number | { id: string | number } ] | string | number | { id: string | number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: update.url(args, {
                    [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                        _method: 'PUT',
                        ...(options?.query ?? options?.mergeQuery ?? {}),
                    }
                }),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\KnowledgeController::update
 * @see app/Http/Controllers/KnowledgeController.php:77
 * @route '/knowledge/{knowledge}'
 */
        updateForm.put = (args: { knowledge: string | number | { id: string | number } } | [knowledge: string | number | { id: string | number } ] | string | number | { id: string | number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: update.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'PUT',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'post',
        })
            /**
* @see \App\Http\Controllers\KnowledgeController::update
 * @see app/Http/Controllers/KnowledgeController.php:77
 * @route '/knowledge/{knowledge}'
 */
        updateForm.patch = (args: { knowledge: string | number | { id: string | number } } | [knowledge: string | number | { id: string | number } ] | string | number | { id: string | number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: update.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'PATCH',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'post',
        })
    
    update.form = updateForm
/**
* @see \App\Http\Controllers\KnowledgeController::destroy
 * @see app/Http/Controllers/KnowledgeController.php:89
 * @route '/knowledge/{knowledge}'
 */
export const destroy = (args: { knowledge: string | number | { id: string | number } } | [knowledge: string | number | { id: string | number } ] | string | number | { id: string | number }, options?: RouteQueryOptions): RouteDefinition<'delete'> => ({
    url: destroy.url(args, options),
    method: 'delete',
})

destroy.definition = {
    methods: ["delete"],
    url: '/knowledge/{knowledge}',
} satisfies RouteDefinition<["delete"]>

/**
* @see \App\Http\Controllers\KnowledgeController::destroy
 * @see app/Http/Controllers/KnowledgeController.php:89
 * @route '/knowledge/{knowledge}'
 */
destroy.url = (args: { knowledge: string | number | { id: string | number } } | [knowledge: string | number | { id: string | number } ] | string | number | { id: string | number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { knowledge: args }
    }

            if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
            args = { knowledge: args.id }
        }
    
    if (Array.isArray(args)) {
        args = {
                    knowledge: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        knowledge: typeof args.knowledge === 'object'
                ? args.knowledge.id
                : args.knowledge,
                }

    return destroy.definition.url
            .replace('{knowledge}', parsedArgs.knowledge.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\KnowledgeController::destroy
 * @see app/Http/Controllers/KnowledgeController.php:89
 * @route '/knowledge/{knowledge}'
 */
destroy.delete = (args: { knowledge: string | number | { id: string | number } } | [knowledge: string | number | { id: string | number } ] | string | number | { id: string | number }, options?: RouteQueryOptions): RouteDefinition<'delete'> => ({
    url: destroy.url(args, options),
    method: 'delete',
})

    /**
* @see \App\Http\Controllers\KnowledgeController::destroy
 * @see app/Http/Controllers/KnowledgeController.php:89
 * @route '/knowledge/{knowledge}'
 */
    const destroyForm = (args: { knowledge: string | number | { id: string | number } } | [knowledge: string | number | { id: string | number } ] | string | number | { id: string | number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: destroy.url(args, {
                    [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                        _method: 'DELETE',
                        ...(options?.query ?? options?.mergeQuery ?? {}),
                    }
                }),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\KnowledgeController::destroy
 * @see app/Http/Controllers/KnowledgeController.php:89
 * @route '/knowledge/{knowledge}'
 */
        destroyForm.delete = (args: { knowledge: string | number | { id: string | number } } | [knowledge: string | number | { id: string | number } ] | string | number | { id: string | number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: destroy.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'DELETE',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'post',
        })
    
    destroy.form = destroyForm
const KnowledgeController = { index, create, store, edit, update, destroy }

export default KnowledgeController