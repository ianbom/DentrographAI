import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition, applyUrlDefaults } from './../../../../wayfinder'
/**
* @see \App\Http\Controllers\DoctorController::index
 * @see app/Http/Controllers/DoctorController.php:14
 * @route '/doctors'
 */
export const index = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index.url(options),
    method: 'get',
})

index.definition = {
    methods: ["get","head"],
    url: '/doctors',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\DoctorController::index
 * @see app/Http/Controllers/DoctorController.php:14
 * @route '/doctors'
 */
index.url = (options?: RouteQueryOptions) => {
    return index.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\DoctorController::index
 * @see app/Http/Controllers/DoctorController.php:14
 * @route '/doctors'
 */
index.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index.url(options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\DoctorController::index
 * @see app/Http/Controllers/DoctorController.php:14
 * @route '/doctors'
 */
index.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: index.url(options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\DoctorController::index
 * @see app/Http/Controllers/DoctorController.php:14
 * @route '/doctors'
 */
    const indexForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: index.url(options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\DoctorController::index
 * @see app/Http/Controllers/DoctorController.php:14
 * @route '/doctors'
 */
        indexForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: index.url(options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\DoctorController::index
 * @see app/Http/Controllers/DoctorController.php:14
 * @route '/doctors'
 */
        indexForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: index.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    index.form = indexForm
/**
* @see \App\Http\Controllers\DoctorController::store
 * @see app/Http/Controllers/DoctorController.php:19
 * @route '/doctors'
 */
export const store = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: store.url(options),
    method: 'post',
})

store.definition = {
    methods: ["post"],
    url: '/doctors',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\DoctorController::store
 * @see app/Http/Controllers/DoctorController.php:19
 * @route '/doctors'
 */
store.url = (options?: RouteQueryOptions) => {
    return store.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\DoctorController::store
 * @see app/Http/Controllers/DoctorController.php:19
 * @route '/doctors'
 */
store.post = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: store.url(options),
    method: 'post',
})

    /**
* @see \App\Http\Controllers\DoctorController::store
 * @see app/Http/Controllers/DoctorController.php:19
 * @route '/doctors'
 */
    const storeForm = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: store.url(options),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\DoctorController::store
 * @see app/Http/Controllers/DoctorController.php:19
 * @route '/doctors'
 */
        storeForm.post = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: store.url(options),
            method: 'post',
        })
    
    store.form = storeForm
/**
* @see \App\Http\Controllers\DoctorController::update
 * @see app/Http/Controllers/DoctorController.php:28
 * @route '/doctors/{doctor}'
 */
export const update = (args: { doctor: string | number } | [doctor: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'put'> => ({
    url: update.url(args, options),
    method: 'put',
})

update.definition = {
    methods: ["put","patch"],
    url: '/doctors/{doctor}',
} satisfies RouteDefinition<["put","patch"]>

/**
* @see \App\Http\Controllers\DoctorController::update
 * @see app/Http/Controllers/DoctorController.php:28
 * @route '/doctors/{doctor}'
 */
update.url = (args: { doctor: string | number } | [doctor: string | number ] | string | number, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { doctor: args }
    }

    
    if (Array.isArray(args)) {
        args = {
                    doctor: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        doctor: args.doctor,
                }

    return update.definition.url
            .replace('{doctor}', parsedArgs.doctor.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\DoctorController::update
 * @see app/Http/Controllers/DoctorController.php:28
 * @route '/doctors/{doctor}'
 */
update.put = (args: { doctor: string | number } | [doctor: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'put'> => ({
    url: update.url(args, options),
    method: 'put',
})
/**
* @see \App\Http\Controllers\DoctorController::update
 * @see app/Http/Controllers/DoctorController.php:28
 * @route '/doctors/{doctor}'
 */
update.patch = (args: { doctor: string | number } | [doctor: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'patch'> => ({
    url: update.url(args, options),
    method: 'patch',
})

    /**
* @see \App\Http\Controllers\DoctorController::update
 * @see app/Http/Controllers/DoctorController.php:28
 * @route '/doctors/{doctor}'
 */
    const updateForm = (args: { doctor: string | number } | [doctor: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: update.url(args, {
                    [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                        _method: 'PUT',
                        ...(options?.query ?? options?.mergeQuery ?? {}),
                    }
                }),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\DoctorController::update
 * @see app/Http/Controllers/DoctorController.php:28
 * @route '/doctors/{doctor}'
 */
        updateForm.put = (args: { doctor: string | number } | [doctor: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: update.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'PUT',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'post',
        })
            /**
* @see \App\Http\Controllers\DoctorController::update
 * @see app/Http/Controllers/DoctorController.php:28
 * @route '/doctors/{doctor}'
 */
        updateForm.patch = (args: { doctor: string | number } | [doctor: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: update.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'PATCH',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'post',
        })
    
    update.form = updateForm
/**
* @see \App\Http\Controllers\DoctorController::destroy
 * @see app/Http/Controllers/DoctorController.php:37
 * @route '/doctors/{doctor}'
 */
export const destroy = (args: { doctor: string | number } | [doctor: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'delete'> => ({
    url: destroy.url(args, options),
    method: 'delete',
})

destroy.definition = {
    methods: ["delete"],
    url: '/doctors/{doctor}',
} satisfies RouteDefinition<["delete"]>

/**
* @see \App\Http\Controllers\DoctorController::destroy
 * @see app/Http/Controllers/DoctorController.php:37
 * @route '/doctors/{doctor}'
 */
destroy.url = (args: { doctor: string | number } | [doctor: string | number ] | string | number, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { doctor: args }
    }

    
    if (Array.isArray(args)) {
        args = {
                    doctor: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        doctor: args.doctor,
                }

    return destroy.definition.url
            .replace('{doctor}', parsedArgs.doctor.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\DoctorController::destroy
 * @see app/Http/Controllers/DoctorController.php:37
 * @route '/doctors/{doctor}'
 */
destroy.delete = (args: { doctor: string | number } | [doctor: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'delete'> => ({
    url: destroy.url(args, options),
    method: 'delete',
})

    /**
* @see \App\Http\Controllers\DoctorController::destroy
 * @see app/Http/Controllers/DoctorController.php:37
 * @route '/doctors/{doctor}'
 */
    const destroyForm = (args: { doctor: string | number } | [doctor: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: destroy.url(args, {
                    [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                        _method: 'DELETE',
                        ...(options?.query ?? options?.mergeQuery ?? {}),
                    }
                }),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\DoctorController::destroy
 * @see app/Http/Controllers/DoctorController.php:37
 * @route '/doctors/{doctor}'
 */
        destroyForm.delete = (args: { doctor: string | number } | [doctor: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: destroy.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'DELETE',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'post',
        })
    
    destroy.form = destroyForm
const DoctorController = { index, store, update, destroy }

export default DoctorController