<?php

return [

    /*
    |--------------------------------------------------------------------------
    | Third Party Services
    |--------------------------------------------------------------------------
    |
    | This file is for storing the credentials for third party services such
    | as Mailgun, Postmark, AWS and more. This file provides the de facto
    | location for this type of information, allowing packages to have
    | a conventional file to locate the various service credentials.
    |
    */

    'postmark' => [
        'key' => env('POSTMARK_API_KEY'),
    ],

    'resend' => [
        'key' => env('RESEND_API_KEY'),
    ],

    'ses' => [
        'key' => env('AWS_ACCESS_KEY_ID'),
        'secret' => env('AWS_SECRET_ACCESS_KEY'),
        'region' => env('AWS_DEFAULT_REGION', 'us-east-1'),
    ],

    'slack' => [
        'notifications' => [
            'bot_user_oauth_token' => env('SLACK_BOT_USER_OAUTH_TOKEN'),
            'channel' => env('SLACK_BOT_USER_DEFAULT_CHANNEL'),
        ],
    ],

    'ai' => [
        'url' => env('AI_SERVICE_URL', 'http://127.0.0.1:8001'),
        'timeout' => (int) env('AI_SERVICE_TIMEOUT', 300),
        'connect_timeout' => (int) env('AI_SERVICE_CONNECT_TIMEOUT', 10),
    ],

    'ai_llm' => [
        'url' => env('AI_LLM_SERVICE_URL', env('AI_SERVICE_URL', 'http://127.0.0.1:8001')),
        'timeout' => (int) env('AI_LLM_SERVICE_TIMEOUT', 60),
        'connect_timeout' => (int) env('AI_LLM_SERVICE_CONNECT_TIMEOUT', 8),
    ],

    'ai_embedding' => [
        'url' => env('AI_EMBEDDING_SERVICE_URL', env('AI_SERVICE_URL', 'http://127.0.0.1:8001')),
        'timeout' => (int) env('AI_EMBEDDING_SERVICE_TIMEOUT', 60),
        'connect_timeout' => (int) env('AI_EMBEDDING_SERVICE_CONNECT_TIMEOUT', 8),
    ],

];
